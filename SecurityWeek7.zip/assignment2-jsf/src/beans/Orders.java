package beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.inject.Inject;
import javax.xml.bind.annotation.XmlRootElement;

import business.OrdersBusinessInterface;

@XmlRootElement

@ManagedBean
public class Orders {

	@Inject 
	OrdersBusinessInterface service; 
	
	List <MyOrder> orders = new ArrayList<MyOrder>();
	
	public void Orders()
	{
		
	}
	
	public void getOrdersAsJson()
	
	void init()
	{
		orders = service.getOrders();
	}
	
	
	public List<MyOrder> getOrders() {
		return orders;
	}

	public void setOrders(List<MyOrder> orders) {
		this.orders = orders;
	}
	
}