package controllers;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.PersistenceContext;
import javax.persistence.EntityManager;

import beans.MyOrder;
import beans.User;
import business.MyTimerService;
import business.OrdersBusinessInterface;

@ManagedBean
@ViewScoped
public class FormController {

	@Inject
	OrdersBusinessInterface services;
	
	@EJB
	MyTimerService timer;
	
	@PersistenceContext(unitName="assignment4a")
	EntityManager em;
	
	
	public void onLogoff()
	{
		// Invalidate the Session to clear the security token
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
			
		// Redirect to a protected page (so we get a full HTTP Request) to get Login Page
		return "TestResponse.xhtml?faces-redirect=true";

	}
	
	public OrdersBusinessInterface getService() {
		return services;
	}
}
